# Advanced string functions
def reverse(string):
	return string[::-1]

def conc(a, b):
	return a+b
